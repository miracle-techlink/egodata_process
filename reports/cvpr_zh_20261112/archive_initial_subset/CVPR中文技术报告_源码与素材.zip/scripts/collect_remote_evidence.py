"""Read-only run evidence collector. Run on the user's server, not via this sandbox.

python collect_remote_evidence.py --runs-root /root/gpufree-data/runs/graph_v5 \
    --output /root/gpufree-data/report_evidence_20261112

Creates a NEW output directory and zip. Does not execute or deserialize checkpoints.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile


def file_sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if not args.runs_root.is_dir():
        raise SystemExit('runs-root does not exist')
    source = args.runs_root.resolve()
    output = args.output.resolve()
    if source == output or source in output.parents or output in source.parents:
        raise SystemExit('Output must be outside the run tree and must not contain it')
    archive = output.with_suffix('.zip')
    if output.exists() or archive.exists():
        raise SystemExit('Refusing to overwrite an existing output or zip')
    output.mkdir(parents=True)
    inventory = []
    for name in ['mamba_base', 'lstm_base', 'transformer_base']:
        run = source/name
        if not run.is_dir():
            inventory.append({'run':name, 'status':'missing_run'})
            continue
        for path in sorted(run.rglob('*')):
            if not path.is_file() or path.is_symlink():
                continue
            suffix = path.suffix.lower()
            if suffix not in {'.json','.jsonl','.yaml','.yml','.csv','.log','.pt','.pth'}:
                continue
            relative = path.relative_to(source)
            size = path.stat().st_size
            digest = file_sha256(path)
            record = {'run':name,'path':str(relative),'bytes':size,'sha256':digest}
            if suffix in {'.pt','.pth'}:
                record['status'] = 'checkpoint_hash_only'
            elif size > 8*1024*1024:
                record['status'] = 'large_file_hash_only'
            else:
                destination = output/relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path,destination)
                copied = file_sha256(destination)
                if copied != digest:
                    raise RuntimeError(f'Source changed during collection: {relative}')
                record['status'] = 'copied'
            inventory.append(record)
    (output/'inventory.json').write_text(json.dumps({'source':str(source),'files':inventory},indent=2))
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(output.rglob('*')):
            if path.is_file():
                z.write(path,path.relative_to(output))
    print(archive)


if __name__ == '__main__':
    main()
