中文 CVPR 技术报告与 Demo 素材包
编写日期：2026-11-12
主题：基于动态人—物交互建模的行为意图预测（egodata_process / EgoDemo / Graph V5）

查看入口
1. main.pdf：中文 CVPR 双栏技术报告，含方法、数据、三骨干实验、统计参照、局限及来源附录。
2. demo_materials.pdf：图片清单、优先级、110秒主demo分镜、已有视频用途与验收要求。
3. 素材清单.csv：可用/待补素材及实际本地路径，UTF-8 BOM，便于Excel打开。
4. figures/：五张论文图及五张实际证据帧；architecture.tex可单独编辑。
5. evidence/：本地证据快照、模型表转录CSV、推导公式、图像来源和SHA。

资料范围
- 当前网络沙箱拒绝SSH连接，提权请求也被权限策略自动拒绝；没有读取服务器最新版。
- 训练数据和模型接口来自本地2026-10-24冻结资料；三骨干结果是训练报告的明确转录。
- 待远端核验项：每个run的最终config、manifest、逐轮日志、benchmark、checkpoint SHA和逐窗口输出。
- 五段场景备份MP4均是133字节Git LFS指针；已存的真实审核帧可用于论文，但不能从指针剪视频。
- 全正预测参照由已知标签计数计算，不是新训练结果；不声称Mamba优于基线。
- 尚未制作预测主demo，已经交付可执行分镜和具体素材需求。

编译
本地：bash build.sh
依赖：TeX Live，XeLaTeX，BibTeX，Fandol中文字体（TeX Live内含）。
Overleaf：上传源码ZIP，Main document选main.tex，Compiler选XeLaTeX；查看素材文档时切换为demo_materials.tex。
所有图已生成，编译PDF不需要Python、网络、GPU或服务器。
cvpr.sty和ieeenat_fullname.bst来自工作区CVPR2026_IR_draft，未修改样式文件。
官方模板来源：https://github.com/cvpr-org/author-kit

重新生成图
scripts/make_figures.py需要原工作区的冻结资料；使用matplotlib/opencv，不使用生成式图像。
统计图嵌入Type 3字形，避免本机Noto CJK集合字体以Type 42嵌入造成标签丢失。
框架图可运行：xelatex -output-directory=figures figures/architecture.tex

远端证据采集（可选，在能够正常登录的服务器终端上运行）
python3 scripts/collect_remote_evidence.py --runs-root /root/gpufree-data/runs/graph_v5 --output /root/gpufree-data/report_evidence_20261112
脚本只读原run，小文件复制到新目录，checkpoint只计算哈希；拒绝覆盖既有输出，不进行训练或网络发送。
脚本仅做本地语法检查，未在远端执行。生成的ZIP应放回本工作区后用于核验与更新报告。

所有成果保存在本地；未提交、未推送、未公开发布。
