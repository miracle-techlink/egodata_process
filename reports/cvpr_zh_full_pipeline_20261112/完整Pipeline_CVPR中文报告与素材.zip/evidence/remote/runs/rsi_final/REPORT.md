# RSI loop report

| rank | name | ok | score | val_loss | macro_seen | rounds |
|---|---|---|---|---|---|---|
| 1 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0001_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 29 |
| 2 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | False | - | - | - | 28 |
| 3 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 2 |
| 4 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.0_selection_metric=val_micro_f1 | False | - | - | - | 5 |
| 5 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.1_selection_metric=val_micro_f1 | False | - | - | - | 40 |
| 6 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.001_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 26 |
| 7 | g_lstm_d_model=128_n_layer=2_dropout=0.0_batch_size=8_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 21 |
| 8 | g_lstm_d_model=128_n_layer=2_dropout=0.1_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 24 |
| 9 | g_lstm_d_model=128_n_layer=2_dropout=0.2_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 31 |
| 10 | g_mamba_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0001_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 18 |
| 11 | g_mamba_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | False | - | - | - | 12 |
| 12 | g_mamba_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 9 |
| 13 | g_mamba_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.0_selection_metric=val_micro_f1 | False | - | - | - | 32 |
| 14 | g_mamba_d_model=128_n_layer=2_dropout=0.0_batch_size=32_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 6 |
| 15 | g_mamba_d_model=128_n_layer=2_dropout=0.0_batch_size=8_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 16 |
| 16 | g_mamba_d_model=128_n_layer=2_dropout=0.1_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 36 |
| 17 | g_mamba_d_model=128_n_layer=3_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 11 |
| 18 | g_mamba_d_model=256_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 8 |
| 19 | g_mamba_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 22 |
| 20 | g_transformer_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | False | - | - | - | 4 |
| 21 | g_transformer_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 20 |
| 22 | g_transformer_d_model=128_n_layer=2_dropout=0.0_batch_size=16_lr=0.001_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 10 |
| 23 | g_transformer_d_model=128_n_layer=2_dropout=0.0_batch_size=32_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 27 |
| 24 | g_transformer_d_model=128_n_layer=2_dropout=0.1_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 25 |
| 25 | g_transformer_d_model=128_n_layer=3_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 23 |
| 26 | g_transformer_d_model=128_n_layer=4_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 3 |
| 27 | g_transformer_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_micro_f1 | False | - | - | - | 1 |
