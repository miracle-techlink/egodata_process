# RSI loop report

| rank | name | ok | score | val_loss | macro_seen | rounds |
|---|---|---|---|---|---|---|
| 1 | g_transformer_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.9140679953106683 | 0.380614420513889 | 0.9282101713964597 | 1 |
| 2 | g_transformer_d_model=64_n_layer=4_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.9140679953106683 | 0.3812422673104842 | 0.9282101713964597 | 3 |
| 3 | g_lstm_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.8778291705211224 | 0.41932482556237344 | 0.9282101713964597 | 2 |
| 4 | g_lstm_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.0_selection_metric=val_loss | True | 0.8775371707076316 | 0.41965576352252565 | 0.9282101713964597 | 5 |
| 5 | g_mamba_d_model=256_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.8685313810149553 | 0.40306123085726187 | 0.9282101713964597 | 8 |
| 6 | g_mamba_d_model=64_n_layer=2_dropout=0.0_batch_size=32_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.8161621585341299 | 0.492148811894643 | 0.9282101713964597 | 6 |
