# RSI loop report

| rank | name | ok | score | val_loss | macro_seen | rounds |
|---|---|---|---|---|---|---|
| 1 | g_mamba_d_model=256_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.8565799842395585 | 0.4892766306457713 | 0.9542242578219085 | 8 |
| 2 | g_lstm_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.0_selection_metric=val_loss | True | 0.838709677419355 | 0.5773476315390776 | 0.9491399297194925 | 5 |
| 3 | g_lstm_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.8373151308304891 | 0.5781940767218102 | 0.9497310146572016 | 2 |
| 4 | g_mamba_d_model=64_n_layer=2_dropout=0.0_batch_size=32_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.8139797068771139 | 0.6163148045993123 | 0.9523295317268958 | 6 |
| 5 | g_transformer_d_model=64_n_layer=4_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.7955625990491283 | 0.6654534490993872 | 0.9371992033389568 | 3 |
| 6 | g_transformer_d_model=64_n_layer=2_dropout=0.0_batch_size=16_lr=0.0003_weight_decay=0.01_selection_metric=val_loss | True | 0.5492760392340028 | 0.7065437604568152 | 0.8540109172070006 | 1 |
